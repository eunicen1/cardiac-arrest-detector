# -*- coding: utf-8 -*-
"""
name
------------------
description
..
:copyright: (c) 2020 Mattia Savardi
:license: BSD 3-clause, see LICENSE for more details.

"""
