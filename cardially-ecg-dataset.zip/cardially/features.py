# -*- coding: utf-8 -*-
"""
Cardially features
------------------
Code for preprocessing, for feature extraction, and for limiting the investigation to different temporal
intervals before the shock.
..
:copyright: (c) 2020 Mattia Savardi
:license: BSD 3-clause, see LICENSE for more details.

"""
import numpy as np
import seaborn as sns
from tqdm import tqdm
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path
from scipy import signal
from scipy import stats
from hurst import compute_Hc
from functools import lru_cache, wraps
import nolds


def np_cache(*args, **kwargs):
    """
    LRU cache implementation for functions whose FIRST parameter is a numpy array
    Source: https://gist.github.com/Susensio/61f4fee01150caaac1e10fc5f005eb75
    TODO: to be tested properly
    """

    def decorator(function):
        @wraps(function)
        def wrapper(self, np_array, *args, **kwargs):
            hashable_array = array_to_tuple(np_array)
            return cached_wrapper(self, hashable_array, *args, **kwargs)

        @lru_cache(*args, **kwargs)
        def cached_wrapper(self, hashable_array, *args, **kwargs):
            array = np.array(hashable_array)
            return function(self, array, *args, **kwargs)

        def array_to_tuple(np_array):
            """Iterates recursively."""
            try:
                return tuple(array_to_tuple(_) for _ in np_array)
            except TypeError:
                return np_array

        # copy lru_cache attributes over too
        wrapper.cache_info = cached_wrapper.cache_info
        wrapper.cache_clear = cached_wrapper.cache_clear

        return wrapper

    return decorator


class Features:
    def __init__(self):
        self.features_list = []

    def __repr__(self):
        return F"{self.__class__.__name__} extraction\n---------------\n" + str(self.features_list)

    def get_features_list(self):
        """
        Return the list of features
        :return: list of (str) available features
        """
        print(F"Available features: {self.features_list}")
        return self.features_list

    def numpy(self):
        """
        Get features and gt as numpy arrays
        :return: Tuple(features, gt)
        """
        if not hasattr(self, 'features'):
            raise Exception("You must call get_features_from_signals on your data beforehand")

        return self.dataframe().iloc[:, 1:].values, self.dataframe()['Class']

    def dataframe(self):
        """
        Return features as pandas DataFrame
        :return: DataFrame
        """
        if not hasattr(self, 'features'):
            raise Exception("You must call get_features_from_signals on your data beforehand")

        return self.features

    def summary(self, plot=True, fn=None):
        """
        Features summary
        :param plot: whether to plot boxplots
        :param fn: save images on the provided path. Don't save if None
        :return: dataframe summary
        """
        if not hasattr(self, 'features'):
            raise Exception("You must call get_features_from_signals on your data beforehand")

        if plot:
            for f in self.features.columns[1:]:
                sns.boxplot(y=f, x='Class', data=self.features, )
                sns.swarmplot(y=f, x='Class', data=self.features,
                              size=3, color=".3", linewidth=0)
                if fn:
                    plt.savefig(Path(fn) / F"{self.__class__.__name__}_{f}.pdf", format="pdf")
                plt.show()

        return self.features.groupby('Class').mean().T

    def get_features_from_signals(self, data, gt=None, feature_list='all'):
        """
        Extract features from a list or array of signals.
        ---
        Example:
            # Extract features and return a summary
            TimeFeatures().get_features_from_signals(data, y).summary()

            # Extract features and return a pandas DataFrame
            TimeFeatures().get_features_from_signals(data, y).dataframe()
        :param data: list or np.array
        :param gt: list of Class
        :param feature_list: list of features to be extracted (see .get_features_list() for a list of available
                              features) or pass 'all'.
        :return: self
        """
        assert isinstance(data, (list, np.ndarray)), "data must either be a list or a np.ndarray"
        cl = None
        out = []
        for i, ds in tqdm(enumerate(data), total=251):
            if isinstance(gt, (list, np.ndarray)):
                cl = gt[i]
            out.append(self.get_features_from_signal(ds, feature_list=feature_list, cl=cl))
        self.features = pd.DataFrame(out)
        return self

    def get_features_from_signal(self, x, feature_list='all', cl=None):
        """
        Extract features from a signal
        :param x: imput signal
        :param feature_list: list of features to be extracted (see .get_features_list() for a list of available
                              features) or pass 'all'.
        :param cl: Class (ROEA, no ROEA)
        :return: dict of features
        """
        if feature_list == 'all':
            feature_list = self.features_list
        elif not isinstance(feature_list, list):
            raise ValueError("feature_list must be either 'all' or a list of valid features")

        tmp = {'Class': cl}
        for feat in feature_list:
            if hasattr(self, feat):
                f = getattr(self, feat)
                tmp[feat] = f(x)
        return tmp


class TimeFeatures(Features):
    def __init__(self, Tp=9, Fs=1000 / 9):
        """
        TimeFeatures: time features extraction
        :param Tp: signal duration in seconds
        :param Fs: sampling frequency [Hz]
        """
        super().__init__()
        self.Tp = Tp
        self.Fs = Fs
        self.dt = 1 / self.Fs
        self.features_list = ['rms', 'sa', 'ma', 'wa', 'ampmax', 'ampmin', 'ptt', 'ppa', 'ms', 'meds']

    def rms(self, x):
        """
        RMS
        :param x: input signal
        :return: Root Mean Square (RMS) - [mV]
        """
        return np.linalg.norm(x) / np.sqrt(len(x))

    def sa(self, x):
        """
        SA
        :param x: input signal
        :return: Average Segment Average (SA) - [uV]
        """
        return np.mean(x) * 1e3

    def ma(self, x):
        """
        MA
        :param x: input signal
        :return: Mean Amplitude (MA) - [mV]
        """
        return np.mean(np.abs(x))

    def wa(self, x):
        """
        WA
        :param x: input signal
        :return: Wave Amplitude (WA) - [mV]
        """

        N = int(1e5)  # samples
        Ares = signal.resample(x, N)

        # zero x crossing
        S = np.sign(Ares)
        idx0 = [0]
        for k in range(N - 1):
            if S[k] == 1 and S[k + 1] == -1:
                idx0.append(k)
        idx0.append(N)

        #  local max & min
        M = np.zeros(len(idx0))
        m = np.zeros(len(idx0))

        for j in range(len(idx0) - 1):
            M[j] = np.max(Ares[idx0[j]:idx0[j + 1]])
            m[j] = np.min(Ares[idx0[j]:idx0[j + 1]])

        return np.mean(np.abs(M - m))

    def ampmax(self, x):
        """
        AmpMax
        :param x: input signal
        :return: Maximum amplitude - [mV]
        """
        return np.max(x)

    def ampmin(self, x):
        """
        AmpMin
        :param x: input signal
        :return: Minimum amplitude - [mV]
        """
        return np.min(x)

    def ptt(self, x):
        """
        PTT
        :param x: input signal
        :return: Peak To Trough (PTT) - [mV]
        """
        return np.abs(np.max(x) - np.min(x))

    def ppa(self, x):
        """
        PPA
        :param x: input signal
        :return: mean peak-pick amplitude - [mV]
        """

        K = self.Tp  # numebr of intervals
        N = len(x)
        s = np.zeros(K)
        for w in range(K):
            local = x[N // K * w + 1:N // K * (w + 1)]
            s[w] = np.abs(np.max(local) - np.min(local))

        return np.mean(s)

    def ms(self, x):
        """
        MS
        :param x: input signal
        :return: Mean Slope (MS) - [mV/s]
        """
        return np.abs(np.mean(np.diff(x)) * self.Fs)

    def meds(self, x):
        """
        MedS
        :param x: input signal
        :return: Median Slope (MedS) - [mV/s]
        """
        return np.abs(np.median(np.diff(x)) * self.Fs)


class FrequencyFeatures(Features):
    def __init__(self, Tp=9, N=1000, fHigh=40):
        """
        FrequencyFeatures: frequency features extraction
        :param Tp: signal duration in seconds
        :param Fs: sampling frequency [Hz]
        """
        super().__init__()
        self.Tp = Tp
        self.N = N
        self.Fs = N / Tp
        self.dt = 1 / self.Fs
        self.df = 1 / self.Tp

        self.f = np.linspace(0, self.Fs - self.df, self.N, endpoint=False)
        self.fLow = self.f[2]
        self.fHigh = fHigh
        self.ifL = np.searchsorted(self.f, self.fLow)
        self.ifH = np.searchsorted(self.f, self.fHigh)
        self.fBand = self.f[self.ifL:self.ifH]

        self.features_list = ['AMSA', 'AMSAabs', 'PSA', 'ENRG', 'CF', 'CP', 'DF', 'EF', 'SFM']

    # @np_cache(maxsize=256)
    def FreqSpectrum(self, x):
        return np.fft.fft(x) * self.dt

    # @np_cache(maxsize=256)
    def absFS(self, x):
        return np.abs(self.FreqSpectrum(x))

    # @np_cache(maxsize=256)
    def PowerSpectrum(self, x):
        return self.absFS(x) ** 2

    def PSD(self, x):
        return self.PowerSpectrum(x)[self.ifL:self.ifH]

    def AMSA(self, x):
        """
        AMplitude Spectrum Area (AMSA) - [mV*Hz]
        :param x: input signal
        :return: float
        """
        return np.sum(self.absFS(x)[self.ifL:self.ifH] * self.fBand)

    def AMSAabs(self, x):
        """
        Absolute value of the AMplitude of the Frequency Spectrum Area (AMSA) - [mV*Hz]
        :param x: input signal
        :return: float
        """
        return np.abs(np.sum(self.FreqSpectrum(x)[self.ifL:self.ifH] * self.fBand))

    def PSA(self, x):
        """
        Power Spectral Analysis (PSA) - [mV^2*Hz]
        :param x: input signal
        :return: float
        """
        return np.sum(self.PSD(x) * self.fBand)

    def ENRG(self, x):
        """
        Energy (ENRG) - [mV^2]
        :param x: input signal
        :return: float
        """
        return np.sum(self.PSD(x)) * self.df

    def CF(self, x):
        """
        Centroid Frequency (CF) - [Hz]
        :param x: input signal
        :return: float
        """
        return np.sum(self.PSD(x) * self.fBand) / sum(self.PSD(x))

    def CP(self, x):
        """
        Centroid Power (CP) - [mV^2]
        :param x: input signal
        :return: float
        """
        return sum(self.PSD(x) ** 2) / sum(self.PSD(x))

    def DF(self, x):
        """
        Dominant Frequency (DF) - [Hz]
        :param x: input signal
        :return: float
        """
        return np.max(self.PSD(x))

    def EF(self, x, p=0.95):
        """
        Edge Frequency (EF) - [Hz]
        :param x: input signal
        :return: float, edge frequency: frequency below which lies the 95% of signal power
        """
        PS = self.PSD(x)
        Energy = np.sum(PS)
        Ep = p * Energy  # edge energy
        sE = 0  # sum Energy
        iEF = 1  # indice EF

        while sE <= Ep:
            iEF = iEF + 1
            sE = np.sum(PS[:iEF])

        if np.abs(Ep - sE) <= np.abs(Ep - np.sum(PS[:iEF - 1])):
            return self.fBand[iEF]
        else:
            return self.fBand[iEF - 1]

    def SFM(self, x):
        """
        spectral Flatness Measure (SFM) - [dB]
        :param x: input signal
        :return: float
        """
        return stats.gmean(self.PSD(x)) / np.mean(self.PSD(x))


class WaveletFeatures(Features):
    def __init__(self, Tp=9, N=1000):
        """
        WaveletFeatures: wavelet features extraction
        :param Tp: signal duration in seconds
        :param N: Number of samples
        """
        super().__init__()
        self.Tp = Tp
        self.N = N
        self.Fs = N / Tp
        self.dt = 1 / self.Fs

        self.features_list = ['energyWavelet']

    def get_features_from_signal(self, x, feature_list='all', cl=None):
        """
        Extract features from a signal
        :param x: imput signal
        :param feature_list: list of features to be extracted (see .get_features_list() for a list of available
                              features) or pass 'all'.
        :param cl: Class (ROEA, no ROEA)
        :return: dict of features
        """
        if feature_list == 'all':
            feature_list = self.features_list
        elif not isinstance(feature_list, list):
            raise ValueError("feature_list must be either 'all' or a list of valid features")

        tmp = {'Class': cl}
        for feat in feature_list:
            if hasattr(self, feat):
                f = getattr(self, feat)
                if feat == 'energyWavelet':
                    inter = f(x)
                    for j, i in enumerate(inter):
                        tmp[feat + str(j)] = i
                else:
                    tmp[feat] = f(x)
        return tmp

    def energyWavelet(self, x):
        """
        ENERGY WAVELET: features in the domain of the Wavelet transform. Energy in bands 1-3Hz, 3-10Hz, 10-32Hz
        :param x: input signal
        :return: float, energy in bands: 1-3Hz, 3-10Hz, 10-32Hz
        """

        fcM = 0.8  # normalized central freq Morlet wavelet
        fc = fcM / self.dt  # central freq
        da = 0.5  # scale step
        a = np.arange(4, 640, da)  # scale
        f = fc / a

        T = signal.cwt(x, signal.morlet, a)
        S = np.square(np.abs(T))

        Cg = 0.5687  # ammissibility coefficient
        Ea = np.zeros(len(a))
        for k in range(len(a)):
            Ea[k] = np.sum(S[k, :]) * self.dt / Cg

        #  Energy in the bands: 1-3Hz, 3-10Hz, 10-32Hz
        fb = [1, 3, 10, 32]
        ind = np.zeros(4, dtype=int)
        for k in range(4):
            d = np.abs(f - fb[k])
            ind[k] = np.argmin(d)

        Eband = np.zeros(3)
        for k in range(3):
            Eband[2 - k] = np.sum(Ea[ind[k + 1] + 1:ind[k]] / np.square(a[ind[k + 1] + 1:ind[k]])) * da
        return Eband


class NonlinaerFeatures(Features):
    def __init__(self, Tp=9, N=1000):
        '''
        NonlinaerFeatures: Nonlinear features extraction
        :param Tp: signal duration in seconds
        :param N: Number of samples
        '''
        super().__init__()
        self.Tp = Tp
        self.N = N
        self.Fs = N / Tp

        self.features_list = ['PSDR', 'PAREA', 'MSI', 'ApEn', 'ShEn', 'H', 'DFA']

    def PSDR(self, x):
        """
        Standard deviation ration of the ellipse fitted into the Poincaré scatter plot
        References: [Tayel2015][Brennan2001], based on: https://github.com/PGomes92/pyhrv/blob/master/pyhrv/nonlinear.py
                   Adapted to this codebase
        :param x: input signal
        :return: float
        """
        x_ = np.asarray(x, dtype='float64')
        # Convert if data has been identified in [s], else proceed with ensuring the NumPy array format
        if np.max(x_) < 10:
            x = np.array([int(p * 1000) for p in x_])
        # Prepare Poincaré data
        x1 = np.asarray(x[:-1])
        x2 = np.asarray(x[1:])

        # SD1 & SD2 Computation
        sd1 = np.std(np.subtract(x1, x2) / np.sqrt(2))
        sd2 = np.std(np.add(x1, x2) / np.sqrt(2))

        return sd1 / sd2

    def PAREA(self, x):
        """
        Area of the ellipse fitted into the Poincaré scatter plot
        References: [Tayel2015][Brennan2001], based on: https://github.com/PGomes92/pyhrv/blob/master/pyhrv/nonlinear.py
                   Adapted to this codebase
        :param x: input signal
        :return: float
        """
        x_ = np.asarray(x, dtype='float64')
        # Convert if data has been identified in [s], else proceed with ensuring the NumPy array format
        if np.max(x_) < 10:
            x = np.array([int(p * 1000) for p in x_])
        # Prepare Poincaré data
        x1 = np.asarray(x[:-1])
        x2 = np.asarray(x[1:])

        # SD1 & SD2 Computation
        sd1 = np.std(np.subtract(x1, x2) / np.sqrt(2))
        sd2 = np.std(np.add(x1, x2) / np.sqrt(2))

        # Area of ellipse
        area = np.pi * sd1 * sd2

        return area

    def MSI(self, x):
        """
        median stepping increment of the Poincare plot
        :param x: input signal
        :return: float
        """
        return np.median(np.sqrt((x[2:] - x[1:-1]) ** 2 + (x[1:-1] - x[:-2]) ** 2) * self.Fs)

    def ApEn(self, x):
        """
        Approximated sample entropy
        :param x: input signal
        :return: float
        """
        return nolds.sampen(x)

    def ShEn(self, x):
        """
        Shannon entropy
        :param x: input signal
        :return: float
        """
        return stats.entropy(np.histogram(x, bins=12)[0])

    def H(self, x):
        """
        hurst exponent
        :param x: input signal
        :return: float
        """
        return compute_Hc(x)[0]

    def DFA(self, x, short=[4, 16]):
        """
        detrended fluctuation analysis.
        References: [Joshua2008][Kuusela2014][Fred2017], based on: https://github.com/PGomes92/pyhrv/blob/master/pyhrv/nonlinear.py Adapted to this codebase
        :param x: input signal
        :param short : array, 2 elements. Interval limits of the short term fluctuations.
        :return: float
        """
        x_ = np.asarray(x, dtype='float64')
        # Convert if data has been identified in [s], else proceed with ensuring the NumPy array format
        if np.max(x_) < 10:
            x = np.array([int(p * 1000) for p in x_])

        short = range(short[0], short[1] + 1)
        alpha1, dfa_short = nolds.dfa(x, short, debug_data=True, overlap=False)

        return alpha1
