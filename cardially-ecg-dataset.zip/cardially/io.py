# -*- coding: utf-8 -*-
"""
Cardially
------------------
This package provides a convenient way of loading ECG file from Cardially project
..
:copyright: (c) 2020 Mattia Savardi
:license: BSD 3-clause, see LICENSE for more details.

"""

from biosppy.signals import ecg
import numpy as np
import pandas as pd
from pathlib import Path
import os
from scipy import interpolate as inter
from scipy.signal import butter, filtfilt
from tqdm import tqdm


class CardiallyReader:
    """This class reads Cardially files and provides functions to plot signals and analyse ground truth data
        Methods
        -------
        load_dataset():
            Load signals from files and retrieve the ground truth.
        numpy():
            Return the loaded data as a tuple of np.ndarray (data, gt).
        summary():
            Prints signals metadata and description to the console.
        plot(idx):
            Plots selected ecg signal.
        get_data():
            Load and preprocess data from a single ecg file.
    """

    def __init__(self, path, metadata=None, extension='txt'):
        self.path = Path(path)
        self.metadata = metadata
        self.extension = extension

    def __repr__(self):
        if not hasattr(self, 'gt'):
            return F"{self.__class__.__name__}: no data loaded "
        else:
            return F"{self.__class__.__name__}: loaded {self.data.shape[0]} signals with {self.data.shape[1]} time " \
                   F"points and classes {str(np.unique(self.gt))}"

    def numpy(self):
        """
        Return the loaded data as a tuple of np.ndarray (data, gt).
        :return: tuple (data: ndarray, gt: ndarray)
        """
        if not hasattr(self, 'gt'):
            print("Loading dataset with default parameters")
            self.load_dataset()
        return self.data, self.gt

    def load_dataset(self, filter=['ROEA', 'noROEA'], **args):
        """
        Load signals from files and retrieve the ground truth.
        :param filter: select only the needed class (ROEA, noROEA, indeterminable)
        :param args: see get_data()
        :return: self class
        """
        X = []
        y = []
        for sdir in tqdm(os.listdir(self.path)):
            if sdir in filter:
                path = self.path / sdir
                for fn in path.glob(F'*.{self.extension}'):
                    X.append(self.get_data(fn, **args))
                    y.append(sdir)
        self.data = np.array(X)
        self.gt = np.array(y)
        return self

    def summary(self, plot=True):
        if not hasattr(self, 'gt'):
            print("Loading dataset with default parameters")
            self.load_dataset()

        print(F"Dataset shape: {self.data.shape}")
        print(F"Gt shape: {self.gt.shape}")
        self.df = pd.DataFrame(self.gt, columns=['Class'])
        self.df['Class'].value_counts().plot(kind='bar')
        return self.df.describe()

    def plot(self, idx=0):
        assert idx < len(self.gt), F"Index must be between 0 and the maximum number of examples {len(self.gt)}"
        print(F"Class {self.gt[idx]}")
        print('=' * 20)
        ecg.ecg(signal=self.data[idx, :], sampling_rate=250, show=True)

    def get_data(self, fn, bandpass=False, resample_length=1000, start=0, end=1000, hcutoff=48, lcutoff=0.5, order=3):
        """Load and preprocess data from ecg-dataset
        s: row of a dataframe with filename and ground truth
        homedir: dataset home path
        resample_length: fixed output length
        bandpass: enable bandpass filtering
        start: modify starting point
        """
        sig = np.loadtxt(fn, usecols=1)
        x = np.linspace(0, 9, len(sig), endpoint=False)
        fun_res = inter.interp1d(x, sig, bounds_error=False, fill_value='extrapolate', kind='cubic')
        sig = fun_res(np.linspace(0, 9, resample_length, endpoint=False))

        if bandpass:
            fs = resample_length / 9
            sig = self.butter_bandpass_filter(sig, lcutoff, hcutoff, fs, order)
        sig = sig[start:end]

        return sig

    @staticmethod
    def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
        b, a = butter(order, [lowcut * 2 / fs, highcut * 2 / fs], btype='band')
        sig = filtfilt(b, a, data)
        return sig
