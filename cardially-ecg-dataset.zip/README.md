# Cardially-ECG-dataset code

Code associated with the Cardially database to load and process ECG signals.

## Reference

Any time you use this code for some publication, please add a reference to

Sergio Benini, Marija D. Ivanovic, Mattia Savardi, Jelena Krsic, Ljupco Hadžievski, Fabio Baronio, "*ECG waveform dataset for predicting defibrillation outcome in out-of-hospital cardiac arrested patients*", in Data in Brief, 2020.



## Installation
This code is developed with Python 3.6. To install the required dependencies open your terminal and execute:
```
pip install -r requirements.txt
```

## Structure
- ```cardially/io.py```: the code for data loading
- ```cartdially/features.py```: the code for features extraction
- ```dataset/pdf/```: the raw dataset as pdf reports (with the three classes in respective folders: ***ROEA***, ***noROEA***,
***indeterminable***)
- ```dataset/txt/```: the extracted dataset in a csv format (with the three classes in respective folders: ***ROEA***, ***noROEA***,
***indeterminable***)

## Abstract
The provided database of 260 ECG signals was collected from patients with out-of-hospital cardiac arrest
while treated by the emergency medical services. Each ECG signal contains a 9 second waveform
showing ventricular fibrillation, followed by 1 minute of post-shock waveform. Patients’ ECGs are made
available in multiple formats. All ECGs recorded during the prehospital treatment are provided in PFD
files, after being anonymized, printed in paper, and scanned. For each ECG, the dataset also includes the
whole digitized waveform (9 s pre- and 1 min post-shock each) and numerous features in temporal and
frequency domain extracted from the 9 s episode immediately prior to the first defibrillation shock.
Based on the shock outcome, each ECG file has been annotated by three expert cardiologists, - using
majority decision -, as successful (56 cases), unsuccessful (195 cases), or indeterminable (9 cases). The
code for preprocessing, for feature extraction, and for limiting the investigation to different temporal
intervals before the shock is also provided. These data could be reused to design algorithms to predict
shock outcome based on ventricular fibrillation analysis, with the goal to optimize the defibrillation
strategy (immediate defibrillation versus cardiopulmonary resuscitation and/or drug administration) for
enhancing resuscitation.

## Value of the Data
- The data can be used by both computer scientists and physicians to perform quantitative analysis of ECG waveform. 
- The data are useful to develop models and classification strategies to predict the defibrillation outcome of out-of-hospital cardiac arrested patients.
- By evaluating the likelihood of a successful defibrillation outcome the optimal timing of delivering the shock can be determined avoiding defibrillation attempts with low probability of success in favour of CPR and chest compression.
- The developed models and algorithms could be made available in the current automated external defibrillators to guide resuscitation protocols with respect to the condition of the patient.

## License

Cardially is released under the BSD 3-clause license. See LICENSE for more details.

## Disclaimer

This program is distributed in the hope it will be useful and provided to you "as is", but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. This program is NOT intended for medical diagnosis. We expressly disclaim any liability whatsoever for any direct, indirect, consequential, incidental or special damages, including, without limitation, lost revenues, lost profits, losses resulting from business interruption or loss of data, regardless of the form of action or legal theory under which the liability may be asserted, even if advised of the possibility of such damages.